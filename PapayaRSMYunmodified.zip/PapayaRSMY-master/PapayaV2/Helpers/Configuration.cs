﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PapayaX2.Helpers
{
    public class Configuration
    {
        public static bool outputErrorStack = true;

        public static int RowPerPage = 30;
    }
}