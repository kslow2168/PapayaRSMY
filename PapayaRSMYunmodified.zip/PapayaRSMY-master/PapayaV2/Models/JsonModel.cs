﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PapayaX2.Models
{
    public class JSonResponse
    {
        public bool Success { get; set; }
        public string Message { get; set; }
    }
}